from mySpace import *

kx = 1; ky = 4; kz = 9; h = 0.01
def field(r):
    return -vec(kx*r.x, ky*r.y, kz*r.z)

for x in range(-9, 10, 2):
    for y in range(-9, 10, 2):
        for z in range(-9, 10, 2):
            r = vec(x, y, z)
            fv = 0.015*field(r)
            arrow(pos=r, axis=fv, color=color.cyan, opacity=0.2)

def f(t, r, v):
    return v
def g(t, r, v):
    return field(r)
def rk4(t, x, v):
    k1 = f(t, x, v)                  ; l1 = g(t, x, v)
    k2 = f(t+h/2, x+h*k1/2, v+h*l1/2); l2 = g(t+h/2, x+h*k1/2, v+h*l1/2)
    k3 = f(t+h/2, x+h*k2/2, v+h*l2/2); l3 = g(t+h/2, x+h*k2/2, v+h*l2/2)
    k4 = f(t+h, x+h*k3, v+h*l3)      ; l4 = g(t+h, x+h*k3, v+h*l3)
    x = x + h*(k1 + 2*k2 + 2*k3 + k4)/6
    v = v + h*(l1 + 2*l2 + 2*l3 + l4)/6
    return x, v

r = vec(1, 0, 0); v = vec(10, 10, -15)
ball = sphere(pos=r, color=color.magenta, make_trail=True, interval=1)
for t in arange(0, 50, h):
    rate(100)
    r, v = rk4(t, r, v)
    ball.pos = r    
