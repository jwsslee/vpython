from mySpace import *

f = gcurve(color=color.magenta)

box(pos=vec(0,-1,0), size=vec(20,2,20), color=color.cyan)
box(pos=vec(-11,0,0), size=vec(2,4,20), color=color.white)
block = box(pos=vec(5,1,0),size=vec(2,2,2),color=color.magenta)
spring = helix(pos=vec(-10,1,0), coils=10, radius=0.7, thickness=0.3)

A = 5
for t in arange(0,20.01,0.01):
    rate(100)
    r = vec(A*cos(t), 1, 0)
    block.pos = r
    spring.axis = r - spring.pos - vec(1,0,0)
    f.plot(t,r.x)
