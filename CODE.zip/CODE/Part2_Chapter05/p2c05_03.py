from vpython import *
graph(width=800, height=600)

f1 = gvbars(delta=0.05, color=color.cyan)
f2 = gdots(color=color.magenta)
for x in arange(-3,3.1,0.1):
    y1 = 2*exp(-x**2)
    y2 = 4*exp(-x**2)
    f1.plot(pos=(x,y1))
    f2.plot(pos=(x,y2))
