from vpython import *
graph(width=800, height=600)

gc = gcurve(color=color.red)
for x in arange(0, 2.01, 0.01):
    y = sin(pi*x)
    gc.plot(x, y)
