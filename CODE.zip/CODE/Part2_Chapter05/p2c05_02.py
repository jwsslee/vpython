from vpython import *
graph(width=800, height=600)

f1 = gcurve(color=color.red)
f2 = gcurve(color=color.blue)
for t in arange(0,20.1,0.1):
    x1 = 5*exp(-0.2*t)*cos(t)
    x2 = 5*cos(t)
    f1.plot(t,x1)
    f2.plot(t,x2)
