s = 0
for i in range(2, 101, 2):
    s = s + i

print("sum(2+4+6+...+98+100):", s)
