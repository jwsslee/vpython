g = 9.8
for i in range(11):
    t = i/10
    y = 10 - 0.5*g*t**2
    print("t=", t, "   ", "y=", y)
