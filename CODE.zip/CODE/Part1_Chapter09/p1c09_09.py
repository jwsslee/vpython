g = 9.8
t = 0.0
y = 10
while y > 0:
    print("t=%4.1f    y=%7.3f" %(t, y))
    t = t + 0.1
    y = 10 - 0.5*g*t**2
