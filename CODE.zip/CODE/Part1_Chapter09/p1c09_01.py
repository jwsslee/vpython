for i in ["hana", "dool", "sed", "ned"]:
    print(i, end=" ")
