for i in range(2, 101, 2):
    print(i, end=" ")
