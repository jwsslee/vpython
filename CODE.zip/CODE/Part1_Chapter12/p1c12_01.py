f = open("test_reading.txt")
text = f.read()
print(text)
