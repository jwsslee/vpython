def factorial(n):
    if n == 0:
        return 1
    else:
        return n * factorial(n-1)

i = 0
f = open("fact_format.txt", "w")
while i <= 10:
    text = "%3d !  = %9d \n" %(i, factorial(i))
    f.write(text)
    i = i + 1

f.close()
