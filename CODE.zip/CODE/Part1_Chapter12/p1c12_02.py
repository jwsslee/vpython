f = open("test_writing.txt", "w")
f.write("Hello, Python! Hello, Physics!\n")
f.write("Hello, Computational Physics!")
f.close()
