f = open("test_writing.txt", "a")
f.write("\n\n")
f.write("Hello, Python!\nThis is an attached text.")
f.close()
