def factorial(n):
    if n == 0:
        return 1
    else:
        return n * factorial(n-1)

f = open("factorial.txt", "w")

for i in range(10):
    text = str(i)+" "+str(factorial(i))+"\n"
    f.write(text)

f.close()
