n = 1
while n <= 100:
    print(n, end=" ")
    n = n + 1
