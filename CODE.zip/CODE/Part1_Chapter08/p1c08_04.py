n = 1
s = 0
while n <= 100:
    m = n%2
    if m == 1:
        s = s + n
    n = n + 1

print("sum(1+3+5+...+97+99):", s)
