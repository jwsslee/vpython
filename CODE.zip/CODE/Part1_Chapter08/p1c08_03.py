n = 2
s = 0
while n <= 100:
    s = s + n
    n = n + 2

print("sum(2+4+6+...+98+100):", s)
