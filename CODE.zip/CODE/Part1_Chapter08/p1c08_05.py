n = 1
s = 1
while n <= 20:
    s = s * n
    n = n + 1

print("factorial(1*2*3*...*19*20):", s)
