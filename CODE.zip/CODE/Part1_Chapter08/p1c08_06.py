N = int(input("Number N: "))

n = 1
s = 1
while n <= N:
    s = s * n
    n = n + 1

print(N, "! =", s)
