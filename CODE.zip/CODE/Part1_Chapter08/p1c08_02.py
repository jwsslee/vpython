n = 1
s = 0
while n <= 100:
    s = s + n
    n = n + 1

print("sum(1+2+...+99+100):", s)
