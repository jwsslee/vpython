loop = True
while loop:
    x = float(input("Number x: "))
    if x > 0.0:
        loop = False
    else:
        print("Input positive number!!!")

print("Square root of", x, "is", x**0.5)
