from mySpace import *

a1 = cylinder(pos=vec(-5,0,0), radius=3, axis=vec(2,0,0), color=color.red)
a2 = cylinder(pos=vec(-3,0,0), radius=1, axis=vec(6,0,0), color=color.green)
a3 = cylinder(pos=vec(3,0,0), radius=3, axis=vec(2,0,0), color=color.blue)
aryung = compound([a1, a2, a3])

rate(1); rate(1); rate(1)

aryung.pos=vec(7,5,0); aryung.axis=vec(0,1,0)
