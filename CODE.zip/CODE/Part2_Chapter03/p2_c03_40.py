from mySpace import *

def f(theta, phi):
    return 5*(3*cos(theta)**2-1)

for phi in range(0, 361, 5):
    p=radians(phi)
    line_theta = curve(color=color.cyan, radius=0.01)
    for theta in range(0, 181, 4):
        t=radians(theta)
        x=f(t,p)*sin(t)*sin(p); y=f(t,p)*cos(t); z=f(t,p)*sin(t)*cos(p)
        line_theta.append(pos=(x,y,z))

for theta in range(0, 181, 2):
    t=radians(theta)
    line_phi = curve(color=color.cyan, radius=0.01)
    for phi in range(0, 361, 10):
        p=radians(phi)
        x=f(t,p)*sin(t)*sin(p); y=f(t,p)*cos(t); z=f(t,p)*sin(t)*cos(p)
        line_phi.append(pos=(x,y,z))
