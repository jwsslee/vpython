from mySpace import *

curve(pos=[(0,0,0),(4,0,10),(8,0,8),(10,0,0)], radius=0.1, color=color.red)
curve(pos=[(0,0,9),(-9,0,6),(-9,0,-6),(0,0,-9)], radius=0.3, color=color.blue)
