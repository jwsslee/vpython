from mySpace import *

for x in range(-9, 10, 2):
    for z in range(-9, 10, 2):
        R=abs(x)/9.0; B=abs(z)/9.0
        pyramid(pos=vec(x,0,z), size=vec(2,2,2), axis=vec(0,1,0), \
                color=vec(R,0,B))
