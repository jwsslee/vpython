from mySpace import *

label(pos=vec(13,0,0), text='X-axis', opacity=0, box=0, line=0, color=color.red)
label(pos=vec(-5,8,5), text='Hello!', height=50, opacity=0, box=0, line=0, \
      color=color.green)
label(pos=vec(0,0,0), text='VPython', height=30, opacity=0, box=0, line=0, \
      color=color.blue)
