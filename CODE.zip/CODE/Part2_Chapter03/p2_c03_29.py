from mySpace import *

ring(pos=vec(0,0,0), axis=vec(0,1,0), radius=3, thickness=1, color=color.red)
ring(pos=vec(4,0,0), axis=vec(0,0,1), radius=3, thickness=1, color=color.green)
ring(pos=vec(-4,0,0), axis=vec(0,0,1), radius=3, thickness=1, color=color.blue)
