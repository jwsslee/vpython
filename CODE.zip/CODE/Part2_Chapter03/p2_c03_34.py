from mySpace import *
from random import random

for x in range(-9, 10, 2):
    for z in range(-9, 10, 2):
        R=random(); G=random(); B=random()
        ellipsoid(pos=vec(x,0,z), size=vec(1,2,2), axis=vec(0,1,0), \
                  color=vec(R,G,B))
