from mySpace import *

point = []
for i in range(-100, 101, 1):
    x = i*0.1
    y = 5*sin(x)
    point.append((x,y,0))
    
curve(pos=point, radius=0.1, color=color.magenta)
