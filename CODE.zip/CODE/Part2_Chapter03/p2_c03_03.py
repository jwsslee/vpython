from mySpace import *

for i in range(-100, 101, 2):
    x = i*0.1
    for j in range(-100, 101, 2):        
        z = j*0.1
        y = 2*(sin(0.5*x)*cos(0.5*z) + 1)
        sphere(pos=vec(x,y,z), radius=0.1, color=color.magenta)
