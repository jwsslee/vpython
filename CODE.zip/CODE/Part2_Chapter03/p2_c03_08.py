from mySpace import *

for i in range(-100, 101, 2):
    x = i*0.1
    y = 5*sin(x)
    nvec = vec(0,1,0)
    cylinder(pos=vec(x,0,0), axis=y*nvec, radius=0.1, color=color.cyan)
