from mySpace import *

def r(t):
    return 8*cos(t)**2

for theta in range(0, 181, 3):
    t=radians(theta)
    for phi in range(0, 361, 6):
        p=radians(phi)
        x=r(t)*sin(t)*sin(p); y=r(t)*cos(t); z=r(t)*sin(t)*cos(p)
        sphere(pos=vec(x,y,z), radius=0.1, color=color.cyan)
