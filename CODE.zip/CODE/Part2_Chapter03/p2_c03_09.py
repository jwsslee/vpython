from mySpace import *

for i in range(-100, 101, 2):
    x = i*0.1
    a = 5*sin(x)
    yvec = vec(0,1,0)
    zvec = vec(0,0,1)
    cylinder(pos=vec(x,0,0), axis=a*yvec, radius=0.1, color=color.red)
    cylinder(pos=vec(x,0,0), axis=a*zvec, radius=0.1, color=color.blue)
