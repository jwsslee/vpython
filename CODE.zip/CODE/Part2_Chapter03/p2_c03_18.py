from mySpace import *

cone(pos=vec(4,0,0), axis=vec(6,0,0), radius=1, color=color.red)
cone(pos=vec(0,0,-4), axis=vec(0,0,-6), radius=2, color=color.blue)

len = 6; nvec = norm(vec(-1,1,1))
cone(pos=vec(0,0,0), axis=len*nvec, radius=3, color=color.yellow)
