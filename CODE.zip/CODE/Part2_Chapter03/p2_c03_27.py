from mySpace import *

box(pos=vec(0,-1,0), size=vec(20,2,20), color=color.green)
box(pos=vec(3,3,-3), size=vec(6,6,6), color=color.white)
pyramid(pos=vec(3,6,-3), size=vec(3,6,6), axis=vec(0,1,0), color=color.orange)
