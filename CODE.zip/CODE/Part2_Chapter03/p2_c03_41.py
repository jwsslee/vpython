from mySpace import *

eps_0 = 8.854e-12
charge_e = 1.602e-19
angstrom = 1.0e-10
const_k = 1.0/(4.0*pi*eps_0)

def electric_field(q, vecr):
    return vecr * const_k * q / mag(vecr)**3

obj_q1 = sphere(pos=vec(-4,0,0), radius=0.4, color=color.red)
obj_q2 = sphere(pos=vec(4,0,0), radius=0.4, color=color.blue)

n1 = 1; q1 = n1 * charge_e
n2 = 1; q2 = -n2 * charge_e
vecr_q1 = angstrom * obj_q1.pos
vecr_q2 = angstrom * obj_q2.pos

h = 0.2; d_theta = pi/9.0; d_phi = pi/4.0
for t in range(20,180,20):
    theta = radians(t)
    for p in range(0,360,30):
        phi = radians(p)
        x = h*cos(theta) 
        y = h*sin(theta)*cos(phi) 
        z = h*sin(theta)*sin(phi)
        point = vec(x,y,z) - obj_q2.pos
        line = curve(pos=[point], color=color.cyan, radius=0.02)
        while mag(point+obj_q1.pos)>obj_q1.radius:
            vecr = angstrom * point
            field_q1 = electric_field(q1, vecr - vecr_q1)
            field_q2 = electric_field(q2, vecr - vecr_q2)
            field = field_q1 + field_q2
            point = point + h * norm(field)
            line.append(pos=point)
