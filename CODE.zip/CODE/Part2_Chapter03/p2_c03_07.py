from mySpace import *

for i in range(-9, 10, 2):
    len = (11-i)*0.5; nvec = vec(0,1,0)
    cylinder(pos=vec(i,0,0), axis=len*nvec, radius=1, color=color.white)
