from mySpace import *

for x in range(-9, 10, 2):
    for z in range(-9, 10, 2):
        fvec = vec(-z, 0, x)
        rvec = 0.2*fvec
        arrow(pos=vec(x,0,z), axis=rvec, color=color.red)
