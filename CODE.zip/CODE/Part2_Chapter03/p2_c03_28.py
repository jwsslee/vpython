from mySpace import *

ring(pos=vec(8,0,0), axis=vec(1,0,0), radius=2, thickness=1, color=color.red)
ring(pos=vec(0,0,-8), axis=vec(0,0,-1), radius=6, thickness=2, color=color.blue)
ring(pos=vec(-3,3,3), axis=vec(-1,1,1), radius=4, thickness=0.5, \
     color=color.yellow)
