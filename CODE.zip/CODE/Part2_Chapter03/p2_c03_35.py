from mySpace import *

helix(pos=vec(4,0,0), axis=vec(6,0,0), coils=20, radius=1, thickness=0.2, \
      color=color.red)
helix(pos=vec(0,0,-4), axis=vec(0,0,-6), coils=10, radius=4, thickness=0.5, \
      color=color.blue)

len = 6; nvec = norm(vec(-1,1,1))
helix(pos=vec(0,0,0), axis=len*nvec, coils=5, radius=2, thickness=1, \
      color=color.yellow)
