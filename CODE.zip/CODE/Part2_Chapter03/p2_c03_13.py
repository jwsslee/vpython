from mySpace import *

for x in range(-9, 10, 2):
    for z in range(-9, 10, 2):
        fvec = -vec(x, 0, z)
        nvec = norm(fvec)
        arrow(pos=vec(x,0,z), axis=nvec, color=color.red)
