from mySpace import *

for i in range(-9, 10, 2):
    len = (11-i)*0.5; nvec = vec(0,1,0)
    arrow(pos=vec(i,0,0), axis=len*nvec, color=color.cyan)
