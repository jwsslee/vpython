from mySpace import *

for theta in range(0, 181, 3):
    t=radians(theta)
    for phi in range(0, 361, 3):
        p=radians(phi)
        x=8*sin(t)*sin(p); y=8*cos(t); z=8*sin(t)*cos(p) 
        sphere(pos=vec(x,y,z), radius=0.1, color=color.cyan)
