from mySpace import *

def efield(r):
    return r / mag(r)**3

p = sphere(pos=vec(-4,0,0), radius=0.4, color=color.red)
m = sphere(pos=vec(4,0,0), radius=0.4, color=color.blue)

for x in range(-9, 10, 2):
    for y in range(-9, 10, 2):
        for z in range(-9, 10, 2):
            r = vec(x,y,z)
            fp = efield(r - p.pos)
            fm = -efield(r - m.pos)
            fvec = fp + fm
            nvec = norm(fvec)
            arrow(pos=vec(x,y,z), axis=nvec, color=color.cyan)
