from mySpace import *

def f(x, z):
    return 2*(sin(0.5*x)*cos(0.5*z)+1)

for i in range(-100, 101, 2):
    x1 = i*0.1
    z2 = i*0.1
    c1 = curve(color=color.magenta, radius=0.01)
    c2 = curve(color=color.magenta, radius=0.01)
    for j in range(-100, 101, 2):        
        z1 = j*0.1
        x2 = j*0.1
        c1.append(pos=(x1,f(x1,z1),z1))
        c2.append(pos=(x2,f(x2,z2),z2))
