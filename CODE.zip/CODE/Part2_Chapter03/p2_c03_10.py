from mySpace import *

arrow(pos=vec(4,0,0), axis=vec(6,0,0), color=color.red)
arrow(pos=vec(0,0,-4), axis=vec(0,0,-6), color=color.blue)

len = 6; nvec = norm(vec(-1,1,1))
arrow(pos=vec(0,0,0), axis=len*nvec, color=color.yellow)
