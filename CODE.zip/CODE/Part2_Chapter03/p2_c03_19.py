from mySpace import *

for i in range(5):
    cone(pos=vec(0,i*2,0), axis=vec(0,4,0), radius=6-i, \
         color=vec(0,(i+1)*0.2,0))
