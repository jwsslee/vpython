from mySpace import *

arrow(pos=vec(-8,0,6), axis=vec(16,0,0), up=vec(0,1,0), color=color.blue)
arrow(pos=vec(-8,0,-6), axis=vec(16,0,0), up=vec(0,1,1), color=color.blue)
