from mySpace import *

ellipsoid(pos=vec(7,0,0), size=vec(6,2,4), axis=vec(1,0,0), color=color.red)
ellipsoid(pos=vec(0,0,-7), size=vec(6,2,4), axis=vec(0,0,-1), color=color.blue)

nvec = norm(vec(-1,1,1))
ellipsoid(pos=vec(-3,3,3), size=vec(6,2,4), axis=nvec, color=color.yellow)
