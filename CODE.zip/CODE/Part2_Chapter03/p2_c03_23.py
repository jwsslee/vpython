from mySpace import *

cylinder(pos=vec(0,0,0), axis=vec(0,12,0), radius=2, color=color.white)
for phi in range(0, 721, 15):
    p=radians(phi)
    x=4*sin(p); z=4*cos(p); y=phi/60.0
    R=G=B=phi/720.0 
    nvec = norm(vec(x,0,z))
    box(pos=vec(x,y,z), size=vec(4,0.2,1), axis=nvec, color=vec(R,G,B))
