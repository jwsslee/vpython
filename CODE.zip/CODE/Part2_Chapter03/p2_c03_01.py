from mySpace import *

for i in range(-30, 31, 1):
    x = i*0.1
    y = x**2
    sphere(pos=vec(x,y,0), radius=0.1, color=color.magenta)
