from mySpace import *

box(pos=vec(0,0,6), size=vec(6,6,6), up=vec(0,1,0), color=color.blue)
box(pos=vec(0,0,-6), size=vec(6,6,6), up=vec(0,1,1), color=color.blue)
