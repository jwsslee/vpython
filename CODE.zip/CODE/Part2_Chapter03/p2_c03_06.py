from mySpace import *

cylinder(pos=vec(4,0,0), axis=vec(6,0,0), radius=1, color=color.red)
cylinder(pos=vec(0,0,-4), axis=vec(0,0,-6), radius=1, color=color.blue)

len = 6; nvec = norm(vec(-1,1,1))
cylinder(pos=vec(0,0,0), axis=len*nvec, radius=1, color=color.yellow)
