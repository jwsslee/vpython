from mySpace import *

for phi in range(0, 361, 5):
    p=radians(phi)
    x=6*sin(p); z=6*cos(p)
    ring(pos=vec(x,0,z), axis=vec(x,0,z), radius=3, thickness=0.2, \
         color=vec(1,0.7,0.2))
