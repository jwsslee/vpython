from mySpace import *

for i in range(-9, 10, 2):
    len = 0.8*abs(i)+3; nvec = vec(0,1,0)
    helix(pos=vec(i,0,0), axis=len*nvec, coils=10, radius=0.8, thickness=0.3, \
          color=vec(0.8,0.8,0.8))
