from mySpace import *

for i in range(-100, 101, 1):
    x = i*0.1
    y = 5*sin(x)
    sphere(pos=vec(x,y,0), radius=0.1, color=color.magenta)
