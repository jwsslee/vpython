from math import *

def f(x):
    return cos(x) - x

a = 0.3; b = 1.1
fa = f(a)

eps = 1.0e-11
while abs(b-a)>eps:
    x = (a+b)/2
    fx = f(x)
    if (fa*fx > 0.0):
        a, fa = x, fx
    else: b = x

print("x =%13.10f" %x)
