from math import *

def f(x):
    return cos(x) - x

def fp(x):
    return -sin(x) - 1

x = 0.1
eps = 1.0e-11
while abs(f(x))>eps:
    x = x - f(x)/fp(x)

print("x =%13.10f" %x)
