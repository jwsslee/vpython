from math import *
from matplotlib.pyplot import *

def f(x):
    return sin(pi*x)

dx = 0.001

x = [i*dx for i in range(1001)]
fx = [f(x[i]) for i in range(1001)]
px = [i*dx for i in range(1,1000)]
fpx = [(fx[i+1]-fx[i-1])/(2*dx) for i in range(1,1000)]

plot(x, fx, 'b-', label='sin(pi*x)')
plot(px, fpx, 'r-', label='d sin(pi*x)/dx')
grid()
legend()
show()
