from math import *
from matplotlib.pyplot import *

def f(x):
    return sin(pi*x)

def fd2(x):
    return -pi**2*sin(pi*x)

dx = 0.001

x = [i*dx for i in range(1001)]
fx = [f(x[i]) for i in range(1001)]
fppx = [(f(x[i]+dx)-2*f(x[i])+f(x[i]-dx))/dx**2 for i in range(1001)]
fd2x = [fd2(x[i]) for i in range(1001)]

plot(x, fx, 'b-', label='sin(pi*x)')
plot(x, fppx, 'r-', label='d2 sin(pi*x)/dx2')
plot(x, fd2x, 'g:', label='-pi**2*sin(pi*x)')
grid()
legend()
show()
