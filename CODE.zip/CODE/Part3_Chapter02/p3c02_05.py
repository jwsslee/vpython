from math import *

def f(x):
    return sin(pi*x)

dx = 0.001

x = [i*dx for i in range(1001)]
fx = [f(x[i]) for i in range(1001)]
dA = [(fx[i]+fx[i+1])*dx/2 for i in range(1000)]
A = sum(dA)

print("Trapezoidal method:", A)
print("Exact value       :", 2/pi)
