from math import *
from matplotlib.pyplot import *

def f(x):
    return sin(pi*x)

def fd(x):
    return pi*cos(pi*x)

dx = 0.001

x = [i*dx for i in range(1001)]
fx = [f(x[i]) for i in range(1001)]
fpx = [(f(x[i]+dx)-f(x[i]-dx))/(2*dx) for i in range(1001)]
fdx = [fd(x[i]) for i in range(1001)]

plot(x, fx, 'b-', label='sin(pi*x)')
plot(x, fpx, 'r-', label='d sin(pi*x)/dx')
plot(x, fdx, 'g:', label='pi*cos(pi*x)')
grid()
legend()
show()
