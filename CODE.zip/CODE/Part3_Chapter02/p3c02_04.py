from math import *
from matplotlib.pyplot import *

def f(x):
    return sin(pi*x)

dx = 0.001

x = [i*dx for i in range(1001)]
fx = [f(x[i]) for i in range(1001)]
ppx = [i*dx for i in range(1,1000)]
fppx = [(fx[i+1]-2*fx[i]+fx[i-1])/dx**2 for i in range(1,1000)]

plot(x, fx, 'b-', label='sin(pi*x)')
plot(ppx, fppx, 'r-', label='d2 sin(pi*x)/dx2')
grid()
legend()
show()
