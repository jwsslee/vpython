from numpy import *
from matplotlib.pyplot import *

y0 = 100.0; gc = 9.8; c2 = 0.003; m = 0.1; b = c2/m
def f(t, y, v):
    return v
def g(t, y, v):
    return -gc + b*v**2

h = 0.01
t = []; y = []; v = []
t.append(0.0); y.append(y0); v.append(0.0)

i = 0
while y[i] > 0.0:
    k1 = f(t[i], y[i], v[i])
    l1 = g(t[i], y[i], v[i])
    k2 = f(t[i]+h/2, y[i]+h*k1/2, v[i]+h*l1/2)
    l2 = g(t[i]+h/2, y[i]+h*k1/2, v[i]+h*l1/2)
    k3 = f(t[i]+h/2, y[i]+h*k2/2, v[i]+h*l2/2)
    l3 = g(t[i]+h/2, y[i]+h*k2/2, v[i]+h*l2/2)
    k4 = f(t[i]+h, y[i]+h*k3, v[i]+h*l3)
    l4 = g(t[i]+h, y[i]+h*k3, v[i]+h*l3)
    y.append(y[i] + h*(k1 + 2*k2 + 2*k3 + k4)/6)
    v.append(v[i] + h*(l1 + 2*l2 + 2*l3 + l4)/6)
    t.append(t[i] + h)
    i = i + 1

def ye(t):
    return y0 - 0.5*gc*t**2
te = linspace(0, 4.517, 1000)
yete = ye(te)

plot(t, y, 'r-', label='Runge-Kutta')
plot(te, yete, 'g:', label='Without drag')
xlabel('t (s)')
ylabel('y (m)')
legend()
grid()
show()
