from vpython import *

y_0 = 100.0; gc = 9.8; m = 0.1; h = 0.01
def f(t, y, v):
    return v
def g0(t, y, v):
    return -gc
def g1(t, y, v):
    c1 = 0.07; b = c1/m
    return -gc - b*v
def g2(t, y, v):
    c2 = 0.003; b = c2/m
    return -gc + b*v**2
def rk4(gi, t, y, v):
    k1 = f(t, y, v)                  ; l1 = gi(t, y, v)
    k2 = f(t+h/2, y+h*k1/2, v+h*l1/2); l2 = gi(t+h/2, y+h*k1/2, v+h*l1/2)
    k3 = f(t+h/2, y+h*k2/2, v+h*l2/2); l3 = gi(t+h/2, y+h*k2/2, v+h*l2/2)
    k4 = f(t+h, y+h*k3, v+h*l3)      ; l4 = gi(t+h, y+h*k3, v+h*l3)
    y = y + h*(k1 + 2*k2 + 2*k3 + k4)/6
    v = v + h*(l1 + 2*l2 + 2*l3 + l4)/6
    return y, v

t = []; y0 = []; v0 = []; y1 = []; v1 = []; y2 = []; v2 = []
t.append(0.0); y0.append(y_0); v0.append(0.0); y1.append(y_0); v1.append(0.0)
y2.append(y_0); v2.append(0.0)
i = 0
while y1[i] > 0.0:
    y0.append(rk4(g0, t[i], y0[i], v0[i])[0])
    v0.append(rk4(g0, t[i], y0[i], v0[i])[1])
    y1.append(rk4(g1, t[i], y1[i], v1[i])[0])
    v1.append(rk4(g1, t[i], y1[i], v1[i])[1])
    y2.append(rk4(g2, t[i], y2[i], v2[i])[0])
    v2.append(rk4(g2, t[i], y2[i], v2[i])[1])
    t.append(t[i] + h)
    if y0[i+1] <= 0.0: y0[i+1] = 0.0
    if y2[i+1] <= 0.0: y2[i+1] = 0.0
    i = i + 1

canvas(background=color.white, width=800, height=600, center=vec(0,50,0))
box(pos=vec(0,-1,0), size=vec(20,2,20), color=color.cyan)
for i in range(0, 101, 10):
    box(pos=vec(0,i,0), size=vec(20,0,20), color=color.cyan, opacity=0.3)
    label(pos=vec(-14,i,10), text=str(i)+' m', opacity=0, box=0, line=0, \
          color=color.magenta)
ball0 = sphere(pos=vec(-6,100,0), radius=1.5, color=color.red)
ball1 = sphere(pos=vec(0,100,0), radius=1.5, color=color.green)
ball2 = sphere(pos=vec(6,100,0), radius=1.5, color=color.blue)
for i in range(len(t)):
    rate(100)
    ball0.pos.y = y0[i]
    ball1.pos.y = y1[i]
    ball2.pos.y = y2[i]
