from mySpace import *

ball = sphere(color=color.magenta)
r0 = vec(-10, 0, 0) # Initial position vector
v0 = vec(2, 0, 0)   # Initial velocity vector
for t in arange(0,10.01,0.01):
    rate(100)
    r = r0 + v0*t
    ball.pos = r
