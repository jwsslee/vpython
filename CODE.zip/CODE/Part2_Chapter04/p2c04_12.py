from mySpace import *

ball = sphere(color=color.magenta, make_trail=True)
A = 10
for t in arange(0,20.01,0.01):
    rate(100)
    r = vec((A-0.5*t)*cos(t), 0.5*t, (A-0.5*t)*sin(t))
    ball.pos = r
cone(radius=10, axis=vec(0,10,0), color=color.cyan, opacity=0.3)
