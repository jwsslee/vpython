from mySpace import *

wing = box(pos=vec(5,0,0), size=vec(10,0.5,2))
w = 2*pi/10.0
dtheta = 0.01*w
for t in arange(0,10.01,0.01):
    rate(100)
    wing.rotate(angle=dtheta, axis=vec(0,1,0), origin=vec(0,0,0))
