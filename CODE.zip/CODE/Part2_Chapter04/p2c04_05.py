from mySpace import *

ball = sphere(color=color.magenta)
r0 = vec(0, 0, 0)   # Initial position vector
v0 = vec(0, 14, 0)  # Initial velocity vector
a = vec(0, -9.8, 0) # Acceleration vector
for t in arange(0,2.81,0.01):
    rate(100)
    r = r0 + v0*t +(1/2)*a*t**2
    ball.pos = r
