from mySpace import *

ball = sphere()
for t in arange(0,10.01,0.01):
    rate(100)
    ball.pos.x = 2*t-10
    if t == 4.0: ball.visible = 0
    if t == 6.0: ball.visible = 1
