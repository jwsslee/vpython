from mySpace import *

ball = sphere(color=color.magenta, make_trail=True)
A = 10
for t in arange(0,20.01,0.01):
    rate(100)
    r = vec(A*cos(t), 0.5*t, A*sin(t))
    ball.pos = r
