from mySpace import *

ball = sphere(color=color.magenta)
A = 10          # Amplitude of oscillation
for t in arange(0,20.01,0.01):
    rate(100)
    r = vec(A*cos(t), 0, 0)
    ball.pos = r
