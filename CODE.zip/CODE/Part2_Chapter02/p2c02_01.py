from mySpace import *

sphere(pos=vec(0,0,0), color=color.white)
sphere(pos=vec(9,0,0), color=color.red)
sphere(pos=vec(0,9,0), color=color.green)
sphere(pos=vec(0,0,9), color=color.blue)
sphere(pos=vec(7,0,-7), radius=3, color=color.yellow)
