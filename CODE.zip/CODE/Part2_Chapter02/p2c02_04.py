from mySpace import *

ball = sphere(pos=vec(0,0,0), radius=1, color=color.white)

rate(1); rate(1); rate(1)

ball.pos=vec(7,0,0)
ball.radius=3
ball.color=color.red
