from vpython import *
canvas(background=color.white, center=vec(15,15,15), forward=vec(-1,-1,-1))

for r in range(0, 31, 3):
    for g in range(0, 31, 3):
        for b in range(0, 31, 3):
            R=r/30.0; G=g/30.0; B=b/30.0
            sphere(pos=vec(r,g,b), color=vec(R,G,B))
