from mySpace import *

sphere(pos=vec(0,0,0), color=vec(1,1,1))
sphere(pos=vec(9,0,0), color=vec(1,0,0))
sphere(pos=vec(0,9,0), color=vec(0,1,0))
sphere(pos=vec(0,0,9), color=vec(0,0,1))
sphere(pos=vec(7,0,-7), radius=3, color=vec(1,1,0))
