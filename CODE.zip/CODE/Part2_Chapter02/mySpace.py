from vpython import *
canvas(background=color.white, width=800, height=600, forward=vec(-3,-2,-3))

curve(pos=[vec(-10,0,0),vec(11,0,0)], radius=0.05, color=color.white)
curve(pos=[vec(0,-10,0),vec(0,11,0)], radius=0.05, color=color.white)
curve(pos=[vec(0,0,-10),vec(0,0,11)], radius=0.05, color=color.white)
cone(pos=vec(11,0,0), axis=vec(0.5,0,0), radius=0.2, color=color.red)
cone(pos=vec(0,11,0), axis=vec(0,0.5,0), radius=0.2, color=color.green)
cone(pos=vec(0,0,11), axis=vec(0,0,0.5), radius=0.2, color=color.blue)

for i in range(-10, 11, 1):
    curve(pos=[vec(i,0,-10),vec(i,0,10)], radius=0.02, color=color.white)
    curve(pos=[vec(-10,0,i),vec(10,0,i)], radius=0.02, color=color.white)
