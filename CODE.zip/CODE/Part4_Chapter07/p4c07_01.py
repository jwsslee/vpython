from vpython import *
canvas(background=color.white, width=800, height=600, forward=vec(-3,-2,-3))
box(pos=vec(0,-1,0), size=vec(240,2,240), color=color.green)
for i in range(-120, 121, 10):
    curve(pos=[(i,0,-120),(i,0,120)], radius=0.2)
    curve(pos=[(-120,0,i),(120,0,i)], radius=0.2)

h = 0.01; theta = 45; v0 = 48; n = 50
def f(t, r, v):
    return v
def g(t, r, v):
    return vec(0, -9.8, 0)
def rk4(t, x, v):
    k1 = f(t, x, v)                  ; l1 = g(t, x, v)
    k2 = f(t+h/2, x+h*k1/2, v+h*l1/2); l2 = g(t+h/2, x+h*k1/2, v+h*l1/2)
    k3 = f(t+h/2, x+h*k2/2, v+h*l2/2); l3 = g(t+h/2, x+h*k2/2, v+h*l2/2)
    k4 = f(t+h, x+h*k3, v+h*l3)      ; l4 = g(t+h, x+h*k3, v+h*l3)
    x = x + h*(k1 + 2*k2 + 2*k3 + k4)/6
    v = v + h*(l1 + 2*l2 + 2*l3 + l4)/6
    return x, v

cost = cos(radians(theta)); sint = sin(radians(theta))
r_list = [vec(-120, 0, 0) for i in range(n)]
v_list = [v0*norm(vec(cost, sint, 0)) for i in range(n)]
b_list = [sphere(pos=r_list[i], color=color.magenta, make_trail=True, \
                 interval=1) for i in range(n)]
for t in arange(0, 3.8, h):
    rate(100)
    for i in range(n):
        r_list[i], v_list[i] = rk4(t, r_list[i], v_list[i])
        b_list[i].pos = r_list[i]
for i in range(n):
    b_list[i].trail_radius = 0.05
    
def bomb(r):
    return 10*r/mag(r)**3
r = [0.1*vec.random() for i in range(n)]; v = [vec(0,0,0) for i in range(n)]
dt = 0.001
for t in arange(0, 0.02, dt):
    for i in range(n-1):
        for j in range(i+1,n):
            v[i] = v[i] + bomb(r[i]-r[j])*dt
            v[j] = v[j] + bomb(r[j]-r[i])*dt
            r[i] = r[i] + v[i]*dt
            r[j] = r[j] + v[j]*dt
for i in range(n):
    v_list[i] = v_list[i] + v[i]

for t in arange(0, 2.5, h):
    rate(100)
    for i in range(n):
        r_list[i], v_list[i] = rk4(t, r_list[i], v_list[i])
        b_list[i].pos = r_list[i]
