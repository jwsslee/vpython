p = 65
if p >= 90:
    print("Rank 1")
elif p >= 80:
    print("Rank 2")
elif p >= 70:
    print("Rank 3")
elif p >= 60:
    print("Rank 4")
else:
    print("Rank 5")
