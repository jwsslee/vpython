if 2<1:
    print("2>1 is True.")
else:
    print("2<1 is False.")
