if 2>1:
    print("2>1 is True.")

if 2<1:
    print("2<1 is False.")
