a = 10
m = a%2
if m == 0:
    print(a, "is even.")
elif m == 1:
    print(a, "is odd.")
else:
    print(a, "is not an integer.")
