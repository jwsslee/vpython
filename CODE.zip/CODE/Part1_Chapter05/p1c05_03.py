s1 = "Hello"
s2 = ", "
s3 = "Python!"

s123 = s1 + s2 + s3

print(s123)
print(s1 * 3)
print(len(s1))
