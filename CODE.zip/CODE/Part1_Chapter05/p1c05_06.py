A = [[1, 2, 3, 4], [5, 6, 7, 8], [9, 10, 11, 12]]
B = [[1, 5], [2, 6], [3, 7], [4, 8]]
C = [[0, 0], [0, 0], [0, 0]]

for i in range(len(C)):
    for k in range(len(C[i])):
        s = 0
        for j in range(len(B)):
            s = s + A[i][j]*B[j][k]
        C[i][k] = s

print(C)
