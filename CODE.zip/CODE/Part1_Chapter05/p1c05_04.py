a = [10, 20, 30, 40, 50]

print("a =", a)
print("len(a) =", len(a))
print("a[0] =", a[0])
print("a[1] =", a[1])
print("a[2] =", a[2])
print("a[1:4] =", a[1:4])

a.append(60)
print("a.append(60), a =", a)

a.remove(20)
print("a.remove(20), a =", a)

a.insert(3, 100)
print("a.insert(3, 100), a =", a)

a.pop(5)
print("a.pop(5), a =", a)
