x = 10
y = 3

print("x =", x)
print("y =", y)
print()
print("-x =", -x)
print("+x =", +x)
print("x + y =", x + y)
print("x - y =", x - y)
print("x * y =", x * y)
print("x / y =", x / y)
print("x // y =", x // y)
print("x % y =", x % y)
print("x ** y =", x ** y)
