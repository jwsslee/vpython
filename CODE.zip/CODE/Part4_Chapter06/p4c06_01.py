from vpython import *
canvas(background=color.white, width=800, height=600, forward=vec(-3,-2,-3))
box(pos=vec(0,-1,0), size=vec(240,2,240), color=color.green)
curve(pos=[(-120,0,0),(120,0,0)], radius=0.5)
curve(pos=[(-120,0,-120),(-120,0,120)], radius=0.5)
for i in range(-120, 121, 10):
    curve(pos=[(i,0,-120),(i,0,120)], radius=0.2)
    curve(pos=[(-120,0,i),(120,0,i)], radius=0.2)
label(pos=vec(-130,0,0), text='0 m', opacity=0, box=0, color=color.blue)
label(pos=vec(130,0,0), text='240 m', opacity=0, box=0, color=color.blue)

bm = 0.0459; br = 0.02135; density = 1.225 
area = pi*br*br; coef = 0.5*density*area/bm

h = 0.01; theta = 10; v0 = 70; w0 = 300; cd = 0.23

def cl(rw, mag_v):
    return -0.05 + sqrt(0.0025+0.36*rw/mag_v)

def gravity():
    return vec(0, -9.8, 0)
def drag(v):
    return -coef*cd*mag(v)**2*norm(v)
def magnus(v):
    nw = norm(vec(0, 0, 1))
    return coef*cl(br*w0, mag(v))*mag(v)**2*cross(nw,norm(v))

def f(t, r, v):
    return v
def g(t, r, v):
    return gravity() + drag(v) + magnus(v)
def rk4(t, x, v):
    k1 = f(t, x, v)                  ; l1 = g(t, x, v)
    k2 = f(t+h/2, x+h*k1/2, v+h*l1/2); l2 = g(t+h/2, x+h*k1/2, v+h*l1/2)
    k3 = f(t+h/2, x+h*k2/2, v+h*l2/2); l3 = g(t+h/2, x+h*k2/2, v+h*l2/2)
    k4 = f(t+h, x+h*k3, v+h*l3)      ; l4 = g(t+h, x+h*k3, v+h*l3)
    x = x + h*(k1 + 2*k2 + 2*k3 + k4)/6
    v = v + h*(l1 + 2*l2 + 2*l3 + l4)/6
    return x, v

cost = cos(radians(theta)); sint = sin(radians(theta))
r = vec(-120, 0, 0); v = v0*norm(vec(cost, sint, 0))
ball = sphere(pos=r, color=color.magenta, make_trail=True, interval=1)
t  = 0.0
while r.y >= 0.0:
    rate(100)
    r, v = rk4(t, r, v)
    ball.pos = r
    t = t + h
    
label(pos=r, text=str(round(r.x+120))+' m', color=color.cyan, opacity=0)
