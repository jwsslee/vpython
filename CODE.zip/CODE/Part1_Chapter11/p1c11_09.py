from myModule import *

print('Free electron mass is', c_me, 'kg.')
print('Force between electrons 0.2 nm apart is', coulomb_force(1,1,0.2e-9),'N.')
print('100 eV in Joule is', eV_to_Joule(100), 'J.')
