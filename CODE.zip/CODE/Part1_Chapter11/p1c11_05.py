from random import randint

N = 1000
n = 0

for i in range(N):
    coin = randint(0, 1)
    if coin == 0:
        n = n + 1
        
print("Probability of heads:", n/N)
