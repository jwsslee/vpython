import random
import matplotlib.pyplot as plt

x = [random.randint(1, 9) for i in range(1000)]

plt.hist(x, bins=18)
plt.show()
