from math import sin, cos, radians

print(" degree     sin         cos")
print(" ---------------------------")
for degree in range(0, 361):
    theta = radians(degree)
    print("%4d     %7.4f     %7.4f" %(degree, sin(theta), cos(theta)))
