from random import randint, random

print("randint(0,10):")
for i in range(20):
    print(randint(0,10), end=" ")

print(); print()

print("random():")
for i in range(20):
    print(random(), end=" ")
