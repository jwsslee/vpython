import time

N = 100000000
s = 0

start = time.time()
for i in range(1, N+1):
    s = s + i
end = time.time()

print("Sum from 1 to", N, ":", s)
print("Time:", end - start, "sec")
