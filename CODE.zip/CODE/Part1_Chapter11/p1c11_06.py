from random import randint

N = 1000
n = 0

for i in range(N):
    dice = randint(1, 6)
    if dice == 3:
        n = n + 1
        
print("Probability of number 3:", n/N)
