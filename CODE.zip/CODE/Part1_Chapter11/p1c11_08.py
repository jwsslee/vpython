from random import random

N = 1000000
n = 0
known_area = 1

for i in range(N):
    x = random()
    y = random()
    if y <= x**3:
        n = n + 1

print("Integral:", known_area*n/N)
