import numpy as np
import matplotlib.pyplot as plt
x = np.linspace(-2*np.pi,2*np.pi,50)
y = np.sin(x)
z = np.cos(x)

plt.figure(); plt.plot(x,y,'r-o')  # fig 1
plt.figure(); plt.plot(x,y,'g--s') # fig 2
plt.figure(); plt.plot(x,y,'b:x')  # fig 3
plt.figure(); plt.plot(x,y,'k-.+') # fig 4

plt.figure() # fig 5
plt.plot(x,y,'m:D')
plt.grid(True)

plt.figure() # fig 6
plt.rc('axes', linewidth=2)
plt.plot(x,y,'c-^')
plt.grid(True)

plt.figure() # fig 7
plt.xlabel('x (s)')
plt.ylabel('y (m)')
plt.plot(x,y,'r-',x,z,'b--')
plt.grid(True)
plt.savefig('Sin_Cos_Plot.png')
plt.show()
