c_e = 1.602e-19         # electronic charge
c_me = 9.110e-31        # free electron mass
c_eps0 = 8.854e-12      # dielectric permittivity of vacuum
c_pi = 3.141592         # constant pi

def coulomb_force(Z1, Z2, r):
    return Z1 * Z2 * c_e**2 / (4.0 * c_pi * c_eps0 * r**2)

def eV_to_Joule(V):
    return c_e * V
