from random import random

N = 1000000
n = 0
area_square = 4

for i in range(N):
    x = 2*random() - 1
    y = 2*random() - 1
    if x**2 + y**2 <= 1:
        n = n + 1

print("Area of the circle (number pi):", area_square*n/N)
