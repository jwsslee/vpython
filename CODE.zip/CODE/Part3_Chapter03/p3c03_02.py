from numpy import *
from matplotlib.pyplot import *

# Exact
def ye(t):
    return exp(t**2)
te = linspace(0, 1, 1001)
yete = ye(te)

# Runge-Kutta
def f(t, y):
    return 2*t*y
h = 0.1
n = int(1/h)
t = zeros(n+1)
y = zeros(n+1)
t[0] = 0.0; y[0] = 1.0
for i in range(n):
    k1 = f(t[i], y[i])
    k2 = f(t[i]+h/2, y[i]+h*k1/2)
    k3 = f(t[i]+h/2, y[i]+h*k2/2)
    k4 = f(t[i]+h, y[i]+h*k3)
    y[i+1] = y[i] + h*(k1 + 2*k2 + 2*k3 + k4)/6
    t[i+1] = t[i] + h

# Plot
plot(te, yete, 'k-', label='Exact')
plot(t, y, 'r:o', label='Runge-Kutta')
grid()
legend()
show()
