from numpy import *
from matplotlib.pyplot import *

# Exact
def ye(t):
    return exp(t**2)
te = linspace(0, 1, 1001)
yete = ye(te)

# Euler
def f(t, y):
    return 2*t*y
h = 0.1
n = int(1/h)
t = zeros(n+1)
y = zeros(n+1)
t[0] = 0.0; y[0] = 1.0
for i in range(n):
    y[i+1] = y[i] + h*f(t[i], y[i])
    t[i+1] = t[i] + h

# Plot
plot(te, yete, 'k-', label='Exact')
plot(t, y, 'r:o', label='Euler')
grid()
legend()
show()
