from numpy import *
from matplotlib.pyplot import *

# Exact
def ye(t):
    return cos(2*t)
te = linspace(0, 7, 1001)
yete = ye(te)

# Runge-Kutta
def f(t, y, v):
    return v
def g(t, y, v):
    return -4*y
h = 0.1
n = int(7/h)
t = zeros(n+1)
y = zeros(n+1)
v = zeros(n+1)
t[0] = 0.0; y[0] = 1.0; v[0] = 0.0
for i in range(n):
    k1 = f(t[i], y[i], v[i])
    l1 = g(t[i], y[i], v[i])
    k2 = f(t[i]+h/2, y[i]+h*k1/2, v[i]+h*l1/2)
    l2 = g(t[i]+h/2, y[i]+h*k1/2, v[i]+h*l1/2)
    k3 = f(t[i]+h/2, y[i]+h*k2/2, v[i]+h*l2/2)
    l3 = g(t[i]+h/2, y[i]+h*k2/2, v[i]+h*l2/2)
    k4 = f(t[i]+h, y[i]+h*k3, v[i]+h*l3)
    l4 = g(t[i]+h, y[i]+h*k3, v[i]+h*l3)
    y[i+1] = y[i] + h*(k1 + 2*k2 + 2*k3 + k4)/6
    v[i+1] = v[i] + h*(l1 + 2*l2 + 2*l3 + l4)/6
    t[i+1] = t[i] + h

# Plot
plot(te, yete, 'k-', label='Exact cos(2t)')
plot(t, y, 'ro', label='Runge-Kutta')
grid()
legend()
show()
