from numpy import *
from matplotlib.pyplot import *

k = 10.0; m = 1.0; h = 0.01; n = int(15/h); w0 = sqrt(k/m)
x_0 = 5.0; v_0 = 0.0; c = 1.0; ga = c/(2*m); F0 = 50.0

def f(t, x, v):
    return v
def g0(t, x, v):
    w = w0
    return -w0**2*x - 2*ga*v - (F0/m)*sin(w*t)
def g1(t, x, v):
    w = w0/2
    return -w0**2*x - 2*ga*v - (F0/m)*sin(w*t)
def g2(t, x, v):
    w = 2*w0
    return -w0**2*x - 2*ga*v - (F0/m)*sin(w*t)
def rk4(gi, t, x, v):
    k1 = f(t, x, v)                  ; l1 = gi(t, x, v)
    k2 = f(t+h/2, x+h*k1/2, v+h*l1/2); l2 = gi(t+h/2, x+h*k1/2, v+h*l1/2)
    k3 = f(t+h/2, x+h*k2/2, v+h*l2/2); l3 = gi(t+h/2, x+h*k2/2, v+h*l2/2)
    k4 = f(t+h, x+h*k3, v+h*l3)      ; l4 = gi(t+h, x+h*k3, v+h*l3)
    x = x + h*(k1 + 2*k2 + 2*k3 + k4)/6
    v = v + h*(l1 + 2*l2 + 2*l3 + l4)/6
    return x, v

t = zeros(n+1)
x0, x1, x2 = zeros(n+1), zeros(n+1), zeros(n+1)
v0, v1, v2 = zeros(n+1), zeros(n+1), zeros(n+1)
t[0] = 0.0
x0[0], x1[0], x2[0] = x_0, x_0, x_0
v0[0], v1[0], v2[0] = v_0, v_0, v_0
for i in range(n):
    x0[i+1], v0[i+1] = rk4(g0, t[i], x0[i], v0[i])
    x1[i+1], v1[i+1] = rk4(g1, t[i], x1[i], v1[i])
    x2[i+1], v2[i+1] = rk4(g2, t[i], x2[i], v2[i])
    t[i+1] = t[i] + h

plot(t, x0, 'r-', label='w = w0')
plot(t, x1, 'g-', label='w = w0/2')
plot(t, x2, 'b-', label='w = 2*w0')
grid()
legend()
show()
