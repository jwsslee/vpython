from numpy import *
from matplotlib.pyplot import *

k0 = 10.0; k = 1.0; h = 0.01; n = int(100/h)
def f(t, r, v):
    return v
def g(t, r, v):
    return array([-k0*r[0]+k*(r[1]-r[0]), -k0*r[1]+k*(r[0]-r[1])])
def rk4(t, x, v):
    k1 = f(t, x, v)                  ; l1 = g(t, x, v)
    k2 = f(t+h/2, x+h*k1/2, v+h*l1/2); l2 = g(t+h/2, x+h*k1/2, v+h*l1/2)
    k3 = f(t+h/2, x+h*k2/2, v+h*l2/2); l3 = g(t+h/2, x+h*k2/2, v+h*l2/2)
    k4 = f(t+h, x+h*k3, v+h*l3)      ; l4 = g(t+h, x+h*k3, v+h*l3)
    x = x + h*(k1 + 2*k2 + 2*k3 + k4)/6
    v = v + h*(l1 + 2*l2 + 2*l3 + l4)/6
    return x, v

t = []
r_list = []
v_list = []
t.append(0.0)
r_list.append(array([2.0,0.0]))
v_list.append(array([0.0,0.0]))
for i in range(n):
    r_list.append(rk4(t[i], r_list[i], v_list[i])[0])
    v_list.append(rk4(t[i], r_list[i], v_list[i])[1])
    t.append(t[i]+h)

x1 = []; x2 = []
for i in range(len(t)):
    x1.append(r_list[i][0])
    x2.append(r_list[i][1])

plot(t, x1, 'r-', label='x1')
plot(t, x2, 'b-', label='x2')
grid()
legend()
show()
