from numpy import *
from matplotlib.pyplot import *

gc = 9.8; l = 1.0; w0 = sqrt(gc/l); h = 0.01; n = int(30/h)
th_0 = 10; th_0 = radians(th_0); wt_0 = 0.0
th_1 = 80; th_1 = radians(th_1); wt_1 = 0.0

def f(t, th, wt):
    return wt
def g0(t, th, wt):
    return -w0**2*th
def g1(t, th, wt):
    return -w0**2*sin(th)
def rk4(gi, t, x, v):
    k1 = f(t, x, v)                  ; l1 = gi(t, x, v)
    k2 = f(t+h/2, x+h*k1/2, v+h*l1/2); l2 = gi(t+h/2, x+h*k1/2, v+h*l1/2)
    k3 = f(t+h/2, x+h*k2/2, v+h*l2/2); l3 = gi(t+h/2, x+h*k2/2, v+h*l2/2)
    k4 = f(t+h, x+h*k3, v+h*l3)      ; l4 = gi(t+h, x+h*k3, v+h*l3)
    x = x + h*(k1 + 2*k2 + 2*k3 + k4)/6
    v = v + h*(l1 + 2*l2 + 2*l3 + l4)/6
    return x, v

t = zeros(n+1)
th0, th1 = zeros(n+1), zeros(n+1)
wt0, wt1 = zeros(n+1), zeros(n+1)
t[0] = 0.0
th0[0], th1[0] = th_0, th_1
wt0[0], wt1[0] = wt_0, wt_1
for i in range(n):
    th0[i+1], wt0[i+1] = rk4(g0, t[i], th0[i], wt0[i])
    th1[i+1], wt1[i+1] = rk4(g1, t[i], th1[i], wt1[i])
    t[i+1] = t[i] + h

plot(t, th0, 'r-', label='w = -w0**2*th')
plot(t, th1, 'b-', label='w = -w0**2*sin(th)')
grid()
legend()
show()
