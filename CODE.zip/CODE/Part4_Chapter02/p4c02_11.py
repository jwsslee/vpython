from numpy import *

k0 = 10.0; k = 1.0; h = 0.01; n = int(100/h)
def f(t, r, v):
    return v
def g(t, r, v):
    return array([-k0*r[0]+k*(r[1]-r[0]), -k0*r[1]+k*(r[0]-r[1])])
def rk4(t, x, v):
    k1 = f(t, x, v)                  ; l1 = g(t, x, v)
    k2 = f(t+h/2, x+h*k1/2, v+h*l1/2); l2 = g(t+h/2, x+h*k1/2, v+h*l1/2)
    k3 = f(t+h/2, x+h*k2/2, v+h*l2/2); l3 = g(t+h/2, x+h*k2/2, v+h*l2/2)
    k4 = f(t+h, x+h*k3, v+h*l3)      ; l4 = g(t+h, x+h*k3, v+h*l3)
    x = x + h*(k1 + 2*k2 + 2*k3 + k4)/6
    v = v + h*(l1 + 2*l2 + 2*l3 + l4)/6
    return x, v

t = []
r_list = []
v_list = []
t.append(0.0)
r_list.append(array([2.0,0.0]))
v_list.append(array([0.0,0.0]))
for i in range(n):
    r_list.append(rk4(t[i], r_list[i], v_list[i])[0])
    v_list.append(rk4(t[i], r_list[i], v_list[i])[1])
    t.append(t[i]+h)

x1 = []; x2 = []
for i in range(len(t)):
    x1.append(r_list[i][0])
    x2.append(r_list[i][1])

from mySpace import *
box(pos=vec(0,-1,0), size=vec(20,2,20), color=color.cyan)
box(pos=vec(-11,0,0), size=vec(2,4,20), color=color.white)
box(pos=vec(11,0,0), size=vec(2,4,20), color=color.white)
bl1 = box(pos=vec(-4,1,0), size=vec(2,2,2), color=color.red)
bl2 = box(pos=vec(4,1,0), size=vec(2,2,2), color=color.blue)
sp0 = helix(pos=vec(0,1,0), coils=8, radius=0.7, thickness=0.1, \
            color=vec(1,0.7,0.2))
sp1 = helix(pos=vec(-10,1,0), coils=8, radius=0.7, thickness=0.3)
sp2 = helix(pos=vec(10,1,0), coils=8, radius=0.7, thickness=0.3)
for i in range(len(t)):
    rate(100)
    bl1.pos.x = x1[i]-4
    bl2.pos.x = x2[i]+4
    sp0.pos.x = bl1.pos.x + 1
    sp1.axis.x = bl1.pos.x - sp1.pos.x - 1
    sp2.axis.x = bl2.pos.x - sp2.pos.x + 1
    sp0.axis.x = bl2.pos.x - sp0.pos.x - 1
