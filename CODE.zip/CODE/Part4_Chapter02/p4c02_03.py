from numpy import *
from matplotlib.pyplot import *

k = 10.0; m = 1.0; w0 = sqrt(k/m); x0 = 5.0; v0 = 0.0
c = 2.0*sqrt(m*k); ga = c/(2*m); A1 = x0; A2 = x0*ga
# Exact
def xe(t):
    return (A1 + A2*t)*exp(-ga*t)

# Runge-Kutta
def f(t, x, v):
    return v
def g(t, x, v):
    return -w0**2*x - 2*ga*v
h = 0.01
n = int(10/h)
t = zeros(n+1)
x = zeros(n+1)
v = zeros(n+1)
xete = zeros(n+1)
t[0] = 0.0; x[0] = x0; v[0] = v0; xete[0] = x0
for i in range(n):
    k1 = f(t[i], x[i], v[i])
    l1 = g(t[i], x[i], v[i])
    k2 = f(t[i]+h/2, x[i]+h*k1/2, v[i]+h*l1/2)
    l2 = g(t[i]+h/2, x[i]+h*k1/2, v[i]+h*l1/2)
    k3 = f(t[i]+h/2, x[i]+h*k2/2, v[i]+h*l2/2)
    l3 = g(t[i]+h/2, x[i]+h*k2/2, v[i]+h*l2/2)
    k4 = f(t[i]+h, x[i]+h*k3, v[i]+h*l3)
    l4 = g(t[i]+h, x[i]+h*k3, v[i]+h*l3)
    x[i+1] = x[i] + h*(k1 + 2*k2 + 2*k3 + k4)/6
    v[i+1] = v[i] + h*(l1 + 2*l2 + 2*l3 + l4)/6
    t[i+1] = t[i] + h
    xete[i+1] = xe(t[i] + h)

# Plot
plot(t, xete, 'k-', label='Exact')
plot(t, x, 'r-', label='Runge-Kutta')
grid()
legend()
show()
