from numpy import *
from vpython import *

gc = 9.8; l = 1.0; w0 = sqrt(gc/l); h = 0.01; n = int(30/h)
th_0 = 10; th_0 = radians(th_0); wt_0 = 0.0
th_1 = 80; th_1 = radians(th_1); wt_1 = 0.0

def f(t, th, wt):
    return wt
def g0(t, th, wt):
    return -w0**2*th
def g1(t, th, wt):
    return -w0**2*sin(th)
def rk4(gi, t, x, v):
    k1 = f(t, x, v)                  ; l1 = gi(t, x, v)
    k2 = f(t+h/2, x+h*k1/2, v+h*l1/2); l2 = gi(t+h/2, x+h*k1/2, v+h*l1/2)
    k3 = f(t+h/2, x+h*k2/2, v+h*l2/2); l3 = gi(t+h/2, x+h*k2/2, v+h*l2/2)
    k4 = f(t+h, x+h*k3, v+h*l3)      ; l4 = gi(t+h, x+h*k3, v+h*l3)
    x = x + h*(k1 + 2*k2 + 2*k3 + k4)/6
    v = v + h*(l1 + 2*l2 + 2*l3 + l4)/6
    return x, v

t = zeros(n+1)
th0, th1 = zeros(n+1), zeros(n+1)
wt0, wt1 = zeros(n+1), zeros(n+1)
t[0] = 0.0
th0[0], th1[0] = th_0, th_1
wt0[0], wt1[0] = wt_0, wt_1
for i in range(n):
    th0[i+1], wt0[i+1] = rk4(g0, t[i], th0[i], wt0[i])
    th1[i+1], wt1[i+1] = rk4(g1, t[i], th1[i], wt1[i])
    t[i+1] = t[i] + h

canvas(background=color.white, width=800, height=600)
cylinder(pos=vec(0,0,-0.2), axis=vec(0,0,0.4), radius=0.05)
string0 = cylinder(pos=vec(0,0,-0.1), axis=l*vec(sin(th_0),-cos(th_0),0), \
                  radius=0.01)
ball0 = sphere(pos=string0.pos+string0.axis, radius=0.1, color=color.red)
string1 = cylinder(pos=vec(0,0,0.1), axis=l*vec(sin(th_1),-cos(th_1),0), \
                  radius=0.01)
ball1 = sphere(pos=string1.pos+string1.axis, radius=0.1, color=color.blue)

for i in range(len(t)):
    rate(100)
    string0.axis = l*vec(sin(th0[i]),-cos(th0[i]),0)
    ball0.pos = string0.pos+string0.axis
    string1.axis = l*vec(sin(th1[i]),-cos(th1[i]),0)
    ball1.pos = string1.pos+string1.axis
