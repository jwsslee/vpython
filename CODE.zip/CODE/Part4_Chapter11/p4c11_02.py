from numpy import *
from matplotlib.pyplot import *

beta = 0.26246; E = 1.5042
a = 5; dx = 0.001; dx22 = dx**2/2; N = int(a/dx)
x = array([i*dx for i in range(N+1)])
V = array([0.0 for i in range(N+1)])
y = array([0.0 for i in range(N+1)])
yp = array([0.0 for i in range(N+1)])
ypp = array([0.0 for i in range(N+1)])

y[0] = 0.0; yp[0] = 0.1; ypp[0] = beta*(V[0] - E)*y[0]
for i in range(N):
    y[i+1] = y[i] + dx*yp[i] + dx22*ypp[i]
    yp[i+1] = yp[i] + dx*ypp[i]
    ypp[i+1] = beta*(V[i+1] - E)*y[i+1]

y2 = y**2
dA = [(y2[i+1]+y2[i])*dx/2.0 for i in range(N)]
A = sum(dA)
y = y/sqrt(A)
y2= y**2

figure(); plot(x, y, label='5A n=1 normalized'); legend(); grid()
xlabel('x [Angstrom]'); ylabel('psi(x) [arb. unit]')
figure(); plot(x, y2, label='5A n=1 normalized'); legend(); grid()
xlabel('x [Angstrom]'); ylabel('psi(x)^2 [arb. unit]')
show()
