g = 9.8

t = 1
y = 10 - 0.5*g*t*t

print(y)


