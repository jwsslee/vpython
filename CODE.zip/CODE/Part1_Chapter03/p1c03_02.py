number1 = 100
number2 = 40

result_plus = number1 + number2
result_minus = number1 - number2

text = "Hello, VPython!"

print(result_plus)
print(result_minus)
print(text)
