a = 1
b = 2
c = -3

x = 2
y = a*x*x + b*x + c

print(y)

