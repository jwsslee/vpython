a = 100
b = 40

c = a + b
d = a - b

e = "Hello, VPython!"

print(c)
print(d)
print(e)
