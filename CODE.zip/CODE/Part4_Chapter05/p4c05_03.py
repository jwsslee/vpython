from vpython import *
from random import *
from matplotlib.pyplot import *

kB = 1.3807E-23; NA = 6.0221E23; MU = 28; m = MU*1E-3/NA; T = 750
vrms = sqrt(3*kB*T/m)

Natom = 50000; Natom2 = int(Natom/2)
collision = 20
start = clock()
v_vec = [vrms*norm(vec.random()) for j in range(Natom)]
for j in range(collision):
    shuffle(v_vec)
    vp_vec = []
    for k in range(Natom2):
        v1 = v_vec[0]; v_vec.pop(0)
        v2 = v_vec[0]; v_vec.pop(0)
        loop = True
        while loop:
            n = norm(vec.random())
            if dot(n, v1)<0 and dot(n, v2)>0: loop = False   
        t = norm(cross(n, cross(norm(v1), n)))
        v1p = dot(v2, n)*n + dot(v1, t)*t
        v2p = v1 + v2 - v1p
        vp_vec.append(v1p); vp_vec.append(v2p)
    v_vec = vp_vec
v_mag = [mag(v_vec[j]) for j in range(Natom)]
end = clock()
print("v_mag max  :", max(v_mag))
print("Time:", end-start)

a = 4*pi*(m/(2*pi*kB*T))**1.5
b = -m/(2*kB*T)
xt = [i for i in range(2001)]
yt = [a*(i**2)*exp(b*(i**2)) for i in range(2001)]
plot(xt, yt, 'r-', label='T = 750 K')
hist(v_mag, bins=100, density=True, label='Simulation')
grid()
legend()
show()
