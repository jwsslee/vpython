from math import *
from matplotlib.pyplot import *

kB = 1.3807E-23; NA = 6.0221E23; MU = 28; m = MU*1E-3/NA
def f(v, T):
    a = 4*pi*(m/(2*pi*kB*T))**1.5
    b = -m/(2*kB*T)
    p = a*(v**2)*exp(b*(v**2))
    return p

v = [i for i in range(3001)]
f_150 = [f(v[i],150) for i in range(3001)]
f_450 = [f(v[i],450) for i in range(3001)]
f_750 = [f(v[i],750) for i in range(3001)]
f_1650 = [f(v[i],1650) for i in range(3001)]

plot(v, f_150, 'r-', label='T = 150 K')
plot(v, f_450, 'g-', label='T = 450 K')
plot(v, f_750, 'b-', label='T = 750 K')
plot(v, f_1650, 'k-', label='T = 1650 K')
grid()
legend()
show()
