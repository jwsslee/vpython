from vpython import *
from matplotlib.pyplot import *

kB = 1.3807E-23; NA = 6.0221E23; MU = 28; m = MU*1E-3/NA; T = 750
vrms = sqrt(3*kB*T/m)

v_list = []
count = 1000000
start = clock()
for i in range(count):
    v1 = vrms*norm(vec.random()); v2 = vrms*norm(vec.random())
    loop = True
    while loop:
        n = norm(vec.random())
        if dot(n, v1)<0 and dot(n, v2)>0: loop = False
    t = norm(cross(n, cross(norm(v1), n)))
    v1p = dot(v2, n)*n + dot(v1, t)*t
    v2p = v1 + v2 - v1p
    v_list.append(mag(v1p)); v_list.append(mag(v2p))
end = clock()
print("v_list max  :", max(v_list))
print("Time:", end-start)

a = 4*pi*(m/(2*pi*kB*T))**1.5
b = -m/(2*kB*T)
xt = [i for i in range(2001)]
yt = [a*(i**2)*exp(b*(i**2)) for i in range(2001)]
plot(xt, yt, 'r-', label='T = 750 K')
hist(v_list, bins=100, density=True, label='Simulation')
grid()
legend()
show()
