x = float(input("x = "))

if x > 3.0:
    print("x =", x, "is in the region of x > 3.0")
    
elif (x >= -3.0) and (x <= 3.0):
    print("x =", x, "is in the region of -3.0 <= x <= 3.0")
    
else:
    print("x =", x, "is in the region of x < -3.0")
