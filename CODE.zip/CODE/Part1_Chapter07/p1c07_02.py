# Solution of quadratic equation: ax2 + bx + c = 0

a = float(input("a = "))
b = float(input("b = "))
c = float(input("c = "))

q = b**2 - 4*a*c

if q > 0:
    print("Two real solution:")
    print("x1 =", (-b + q**0.5)/(2.0*a))
    print("x2 =", (-b - q**0.5)/(2.0*a))
    
elif q == 0:
    print("One real solution:")
    print("x =", -b/(2.0*a))
    
else:
    print("No real solution.")
