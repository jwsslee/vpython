from mySpace import *

h = 0.01
def field(r):
    return r/mag(r)**3

def f(t, r, v):
    return v
def g(t, r, v):
    return field(r)
def rk4(t, x, v):
    k1 = f(t, x, v)                  ; l1 = g(t, x, v)
    k2 = f(t+h/2, x+h*k1/2, v+h*l1/2); l2 = g(t+h/2, x+h*k1/2, v+h*l1/2)
    k3 = f(t+h/2, x+h*k2/2, v+h*l2/2); l3 = g(t+h/2, x+h*k2/2, v+h*l2/2)
    k4 = f(t+h, x+h*k3, v+h*l3)      ; l4 = g(t+h, x+h*k3, v+h*l3)
    x = x + h*(k1 + 2*k2 + 2*k3 + k4)/6
    v = v + h*(l1 + 2*l2 + 2*l3 + l4)/6
    return x, v

sphere(color=color.cyan)
for i in range(-20, 21):
    r = vector(-10,0,i/2.0)
    v = vector(0.7,0,0)
    proton = sphere(pos=r, radius=0.3, color=color.magenta, make_trail=True, \
                interval=1)
    for t in arange(0, 40, h):
        rate(5000)
        r, v = rk4(t, r, v)
        proton.pos = r
