from vpython import *
scene.background = color.white; scene.width = 800; scene.height = 600
va = vector(1,0,0)
vb = vector(0,1,0)
vc = vector(0,0,1)
na = 3; nb = 3; nc = 3
scene.center = 0.5*(na*va + nb*vb + nc*vc)
for i in range(na+1):
    for j in range(nb+1):
        for k in range(nc+1):
            r = i*va + j*vb + k*vc
            sphere(pos=r, radius=0.1, color=color.magenta)
            if r.x<na: cylinder(pos=r, axis=va, radius=0.02, color=vec(0,1,1))
            if r.y<nb: cylinder(pos=r, axis=vb, radius=0.02, color=vec(0,1,1))
            if r.z<nc: cylinder(pos=r, axis=vc, radius=0.02, color=vec(0,1,1))
