from vpython import *
scene.background = color.white; scene.width = 800; scene.height = 600
va = vector(1,0,0)
vb = vector(0,1,0)
vc = vector(0,0,1)
b0 = vector(0,0,0)
b1 = 0.5*(va+vb+vc)
c1 = 0.5*(va+vb+vc); c2 = 0.5*(-va+vb+vc)
c3 = 0.5*(va-vb+vc); c4 = 0.5*(va+vb-vc)
c5 = 0.5*(va-vb-vc); c6 = 0.5*(-va+vb-vc)
c7 = 0.5*(-va-vb+vc); c8 = 0.5*(-va-vb-vc)
na = 3; nb = 3; nc = 3
scene.center = 0.5*(na*va + nb*vb + nc*vc)
for i in range(na+1):
    for j in range(nb+1):
        for k in range(nc+1):
            r = i*va + j*vb + k*vc
            if r.x<na: cylinder(pos=r, axis=va, radius=0.005, color=vec(0,0,0))
            if r.y<nb: cylinder(pos=r, axis=vb, radius=0.005, color=vec(0,0,0))
            if r.z<nc: cylinder(pos=r, axis=vc, radius=0.005, color=vec(0,0,0))
            sphere(pos=r+b0, radius=0.1, color=color.magenta)
            if (i<na) and (j<nb) and (k<nc):
                sphere(pos=r+b1, radius=0.1, color=color.magenta)
                cylinder(pos=r+b1, axis=c1, radius=0.02, color=vec(0,1,1))
                cylinder(pos=r+b1, axis=c2, radius=0.02, color=vec(0,1,1))
                cylinder(pos=r+b1, axis=c3, radius=0.02, color=vec(0,1,1))
                cylinder(pos=r+b1, axis=c4, radius=0.02, color=vec(0,1,1))
                cylinder(pos=r+b1, axis=c5, radius=0.02, color=vec(0,1,1))
                cylinder(pos=r+b1, axis=c6, radius=0.02, color=vec(0,1,1))
                cylinder(pos=r+b1, axis=c7, radius=0.02, color=vec(0,1,1))
                cylinder(pos=r+b1, axis=c8, radius=0.02, color=vec(0,1,1))
