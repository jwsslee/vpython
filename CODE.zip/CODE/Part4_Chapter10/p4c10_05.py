from vpython import *
scene.background = color.white; scene.width = 800; scene.height = 600

cp = []
CM = vector(0.0, 0.0, 0.0)
f = open('C60POS.txt')
for i in range(60):
    text = f.readline()
    tsplit = text.split()
    tlist = list(map(float, tsplit))
    cp.append(vector(tlist[0], tlist[1], tlist[2]))
    CM = CM + cp[i]
f.close()

scene.center = CM/60.0
for i in range(60):
    sphere(pos=cp[i], radius=0.2, color=color.magenta)

cb = []
f = open('C60BOND.txt')
for i in range(90):
    text = f.readline()
    tsplit = text.split()
    tlist = list(map(int, tsplit))
    cb.append(tlist)
f.close()

for i in range(90):
    cylinder(pos=cp[cb[i][0]], axis=cp[cb[i][1]]-cp[cb[i][0]], \
             radius=0.04, color=color.cyan)
