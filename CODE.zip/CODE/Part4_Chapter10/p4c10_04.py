from vpython import *
scene.background = color.white; scene.width = 800; scene.height = 600
va = vector(1,0,0); vb = vector(0,1,0); vc = vector(0,0,1)
b0 = vector(0,0,0); b1 = 0.5*(va+vb); b2 = 0.5*(vb+vc); b3 = 0.5*(va+vc)
di = 0.25*(va+vb+vc)
c1 = 0.25*(-va-vb-vc); c2 = 0.25*(-va+vb+vc)
c3 = 0.25*(va-vb+vc); c4 = 0.25*(va+vb-vc)

na = 3; nb = 3; nc = 3
scene.center = 0.5*(na*va + nb*vb + nc*vc)
for i in range(na+1):
    for j in range(nb+1):
        for k in range(nc+1):
            r = i*va + j*vb + k*vc
            if r.x<na: cylinder(pos=r, axis=va, radius=0.005, color=vec(0,0,0))
            if r.y<nb: cylinder(pos=r, axis=vb, radius=0.005, color=vec(0,0,0))
            if r.z<nc: cylinder(pos=r, axis=vc, radius=0.005, color=vec(0,0,0))
            rb = r + b0
            if (rb.x<=na) and (rb.y<=nb) and (rb.z<=nc):
                sphere(pos=rb, radius=0.1, color=color.blue)
            rb = r + b0 + di
            if (rb.x<=na) and (rb.y<=nb) and (rb.z<=nc):
                sphere(pos=rb, radius=0.1, color=color.cyan)
                cylinder(pos=rb, axis=c1, radius=0.02, color=color.yellow)
                cylinder(pos=rb, axis=c2, radius=0.02, color=color.yellow)
                cylinder(pos=rb, axis=c3, radius=0.02, color=color.yellow)
                cylinder(pos=rb, axis=c4, radius=0.02, color=color.yellow)
            rb = r + b1
            if (rb.x<=na) and (rb.y<=nb) and (rb.z<=nc):
                sphere(pos=rb, radius=0.1, color=color.blue)
            rb = r + b1 + di
            if (rb.x<=na) and (rb.y<=nb) and (rb.z<=nc):
                sphere(pos=rb, radius=0.1, color=color.cyan)
                cylinder(pos=rb, axis=c1, radius=0.02, color=color.yellow)
                cylinder(pos=rb, axis=c2, radius=0.02, color=color.yellow)
                cylinder(pos=rb, axis=c3, radius=0.02, color=color.yellow)
                cylinder(pos=rb, axis=c4, radius=0.02, color=color.yellow)
            rb = r + b2
            if (rb.x<=na) and (rb.y<=nb) and (rb.z<=nc):
                sphere(pos=rb, radius=0.1, color=color.blue)
            rb = r + b2 + di
            if (rb.x<=na) and (rb.y<=nb) and (rb.z<=nc):
                sphere(pos=rb, radius=0.1, color=color.cyan)
                cylinder(pos=rb, axis=c1, radius=0.02, color=color.yellow)
                cylinder(pos=rb, axis=c2, radius=0.02, color=color.yellow)
                cylinder(pos=rb, axis=c3, radius=0.02, color=color.yellow)
                cylinder(pos=rb, axis=c4, radius=0.02, color=color.yellow)
            rb = r + b3
            if (rb.x<=na) and (rb.y<=nb) and (rb.z<=nc):
                sphere(pos=rb, radius=0.1, color=color.blue)
            rb = r + b3 + di
            if (rb.x<=na) and (rb.y<=nb) and (rb.z<=nc):
                sphere(pos=rb, radius=0.1, color=color.cyan)
                cylinder(pos=rb, axis=c1, radius=0.02, color=color.yellow)
                cylinder(pos=rb, axis=c2, radius=0.02, color=color.yellow)
                cylinder(pos=rb, axis=c3, radius=0.02, color=color.yellow)
                cylinder(pos=rb, axis=c4, radius=0.02, color=color.yellow)
