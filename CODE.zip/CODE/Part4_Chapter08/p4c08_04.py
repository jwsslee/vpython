from mySpace import *

lda = 12.2e-12; k = 2.0*pi/lda
A = 1.0e-9
Aa = 2*A; Aa2 = Aa; Aa3 = A
Ab = 2*A; Ab2 = Ab
D = 1.0; D2 = D*D
Ndelta = 40; Adelta = Aa/Ndelta

def f(xs, ys):
    Int = 0+0j
    for xa in arange(-Aa2, Aa2+Adelta, Adelta):
        for ya in arange(-Ab2, Ab2+Adelta, Adelta):
            if not(-Aa3<xa<Aa3):
                xsa = xs-xa; ysa = ys-ya
                r = sqrt(xsa*xsa+ysa*ysa+D2)
                Int = Int + complex(cos(k*r),sin(k*r))/r 
    return Int
  
Max = abs(f(0.0,0.0))
tracex = curve(color=color.red)
tracey = curve(color=color.blue)
for i in arange(-10.125, 10.13, 0.25):
    j = i*3e-3
    Ix = 10*(abs(f(j,0.0))/Max)**2
    Iy = 10*(abs(f(0.0,j))/Max)**2
    tracex.append(pos=vec(i,Ix,0))
    tracey.append(pos=vec(0,Iy,i))
    rate(10000)

for x in arange(-10.125, 10.13, 0.25):
    xs = x*3e-3
    for y in arange(-10.125, 10.13, 0.25):
        ys = y*3e-3
        I = 10*(abs(f(xs,ys))/Max)**2
        if I>=0.2: I=0.2
        box(pos=vec(x,0,y), size=vec(0.25,0.1,0.25), color=vec(0,I/0.2,0))
        rate(10000)
