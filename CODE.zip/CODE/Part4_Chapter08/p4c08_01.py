from mySpace import *

lda = 6.33e-7; k = 2.0*pi/lda
A = 3.39e-5
Ab = 2*A; Ab2 = Ab/2.0; rb2 = Ab2*Ab2
D = 8.0; D2 = D*D
Ndelta = 20; Adelta = A/Ndelta

def f(xs, ys):
    Int = 0+0j
    for xa in arange(-Ab2, Ab2+Adelta, Adelta):
        for ya in arange(-Ab2, Ab2+Adelta, Adelta):
            if xa*xa+ya*ya<=rb2:
                xsa = xs-xa; ysa = ys-ya
                r = sqrt(xsa*xsa+ysa*ysa+D2)
                Int = Int + complex(cos(k*r),sin(k*r))/r 
    return Int
  
Max = abs(f(0.0,0.0))
tracex = curve(color=color.magenta)
tracey = curve(color=color.cyan)
for i in arange(-10.125, 10.13, 0.25):
    j = i*0.03
    Ix = 10*(abs(f(j,0.0))/Max)**2
    Iy = 10*(abs(f(0.0,j))/Max)**2
    tracex.append(pos=vec(i,Ix,0))
    tracey.append(pos=vec(0,Iy,i))
    rate(10000)

for x in arange(-10.125, 10.13, 0.25):
    xs = x*0.03
    for y in arange(-10.125, 10.13, 0.25):
        ys = y*0.03
        I = 10*(abs(f(xs,ys))/Max)**2
        if I>=0.1: I=0.1
        box(pos=vec(x,0,y), size=vec(0.25,0.1,0.25), color=vec(I/0.1,0,0))
        rate(10000)
