def line():
    print("-" * 15)

print("Hello, Python!")
line()
print("Hello, World!")
line()
print("Hello, Hallym University!")
