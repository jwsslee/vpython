a = 2
def f(x):
    b = 1
    y = a*x + b
    return y

print(f(5))
print(a*5 + b)
