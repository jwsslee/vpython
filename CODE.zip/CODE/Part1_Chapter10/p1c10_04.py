def f(x):
    y = x**2 + 2*x - 3
    return y

x = -4.0
while x < 2.1:
    print("f( %4.1f )= %6.2f" %(x, f(x)))
    x = x + 0.1
