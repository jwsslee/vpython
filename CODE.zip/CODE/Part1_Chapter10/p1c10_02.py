def print_sqrt(x):
    print("sqrt(", x, ")=", x**0.5)

print_sqrt(3)
