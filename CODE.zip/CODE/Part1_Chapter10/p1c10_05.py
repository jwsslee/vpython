def FtoC(F):
    C = (F - 32)/1.8
    return C

print(86, "F =", FtoC(86), "C")
