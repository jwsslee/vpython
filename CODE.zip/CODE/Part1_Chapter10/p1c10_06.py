pi = 3.141592
def circumference(r):
    return 2.0*pi*r

def area_circle(r):
    return pi*r**2

def volume_sphere(r):
    return 4.0*pi*r**3/3.0

print('The circumference of radius = 1.0 is', circumference(1.0))
print('The area of a circle with radius = 2.0 is', area_circle(2.0))
print('The volume of a sphere with radius = 3.0 is', volume_sphere(3.0))
