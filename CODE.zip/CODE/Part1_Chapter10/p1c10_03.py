def f(x):
    y = 2*x + 1
    return y

for i in range(5):
    print("f(", i, ")=", f(i))
