from mySpace import *

v1 = 3*norm(vec.random())
v2 = 3*norm(vec.random())
loop = True
while loop:
    n = norm(vec.random())
    if dot(n, v1)<0 and dot(n, v2)>0: loop = False
t = norm(cross(n, cross(norm(v1), n)))
v1p = dot(v2, n)*n + dot(v1, t)*t
v2p = v1 + v2 - v1p
print("Energy before collision:", 0.5*mag(v1)**2 + 0.5*mag(v2)**2)
print("Energy after collision :", 0.5*mag(v1p)**2 + 0.5*mag(v2p)**2)

arrow(pos=-v1, axis=v1, color=color.cyan)
arrow(pos=-v2, axis=v2, color=color.magenta)
arrow(axis=v1p, color=color.blue)
arrow(axis=v2p, color=color.red)
arrow(pos=-2*n*3, axis=4*n*3, shaftwidth=0.05, color=color.yellow)
arrow(pos=-2*t*3, axis=4*t*3, shaftwidth=0.05, color=color.green)
for i in range(1, 11):
    ring(axis=n, radius=3*i/10, thickness=0.02, color=color.green)

r1 = -3*v1; r2 = -3*v2
b1 = sphere(pos=r1, color=color.blue, make_trail=True, interval=1)
b2 = sphere(pos=r2, color=color.red, make_trail=True, interval=1)
h = 0.01
while mag(r1) <= 10 and mag(r2) <= 10:
    rate(100)
    r1 = r1 + v1*h; b1.pos = r1
    r2 = r2 + v2*h; b2.pos = r2
    if mag(r1-r2) <= 2:
        v1 = v1p; v2 = v2p
