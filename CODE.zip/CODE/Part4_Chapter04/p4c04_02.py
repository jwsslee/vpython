from mySpace import *

box(pos=vec(0,-1,0), size=vec(20,2,20), color=color.cyan)
p1 = cylinder(pos=vec(-9,0,1), axis=vec(0,0.5,0), color=color.red, \
              make_trail=True, interval=1)
p2 = cylinder(pos=vec(1,0,0), axis=vec(0,0.5,0), color=color.blue, \
              make_trail=True, interval=1)

h = 0.01
r1 = p1.pos; r2 = p2.pos; v1 = vec(3, 0, 0); v2 = vec(0, 0, 0)
while abs(r1.x)<=9 and abs(r1.z)<=9 and abs(r2.x)<=9 and abs(r2.z)<=9:
    rate(100)
    r1 = r1 + v1*h; p1.pos = r1
    r2 = r2 + v2*h; p2.pos = r2
    if mag(r1-r2) <= 2:
        n = norm(r2 - r1); t = norm(cross(n,cross(v1,n)))
        v1n = dot(n,v1)*n; v2n = dot(n,v2)*n
        v1n, v2n = v2n, v1n
        v1t = dot(t,v1)*t
        v1p = v1n + v1t
        v2p = v1 + v2 - v1p
        arrow(pos=r1+n, axis=5*n, shaftwidth=0.2, color=color.yellow)
        arrow(pos=r1+n, axis=5*t, shaftwidth=0.2, color=color.green)
        print(0.5*(mag(v1)**2+mag(v2)**2), 0.5*(mag(v1p)**2+mag(v2p)**2))
        print(degrees(diff_angle(v1p,v2p)))
        v1 = v1p; v2 = v2p
