from mySpace import *

box(pos=vec(0,-1,0), size=vec(20,2,20), color=color.cyan)
bl1 = box(pos=vec(-9,1,0), size=vec(2,2,2), color=color.red)
bl2 = box(pos=vec(1,1,0), size=vec(2,2,2), color=color.blue)

h = 0.01
r1 = bl1.pos; r2 = bl2.pos; v1 = vec(3, 0, 0); v2 = vec(0, 0, 0)
while r1.x >= -9 and r2.x <= 9:
    rate(100)
    r1 = r1 + v1*h; bl1.pos = r1
    r2 = r2 + v2*h; bl2.pos = r2
    if mag(r1-r2) <= 2:
        v1, v2 = v2, v1
