import vpython as vp

vp.sphere()
