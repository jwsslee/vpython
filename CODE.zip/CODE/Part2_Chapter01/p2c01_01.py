from vpython import *

A = vector(1, 1, 2)
B = vector(1, 0, 1)
print("Vector A:", A, "    Magnitude of A:", mag(A))
print("Vector B:", B, "    Magnitude of B:", mag(B))
print("A + B =", A + B)
print("A - B =", A - B)
print("Scalar multiplication 5.0*A:", 5.0*A)
print("Dot product                   :", dot(A, B))
print("Cross product                 :", cross(A ,B))
print("Normalized unit vector of A:", norm(A))
